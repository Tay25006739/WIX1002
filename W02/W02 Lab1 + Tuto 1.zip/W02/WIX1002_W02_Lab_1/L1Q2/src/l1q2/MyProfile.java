/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package l1q2;

/**
 *
 * @author Tay
 */
public class MyProfile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("My Name is Tay Zheheng");
        System.out.println("My matric number is 25006739");
        System.out.println("My email address is 25006739@siswa.um.edu.my");
        System.out.println("My contact number is 011-58984948");
        System.out.println("Nice to meet you all");
    }
    
}
