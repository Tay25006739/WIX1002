package com.example;

/**
 * Hello world!
 *
 */
public class T2Q1
{
    public static void main( String[] args )
    {
        System.out.println("Display sentence : \"Faculty of Computer Science and Information Technology\"");
        System.out.println(" ");
        System.out.println("==== Method 1 : In one line using multiple Java statement====");
        String sentence = "Faculty of Computer Science and Information Technology";System.out.println(sentence);
        System.out.println(" ");
        System.out.println("==== Method 2 : In multiple line using one Java statement ====");
        System.out.print("Faculty of Computer Science");
        System.out.println(" and Information Technology");
    }
}
