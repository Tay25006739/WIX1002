package com.example;

/**
 * Hello world!
 *
 */
public class T2Q2
{
    public static void main( String[] args )
    {
        System.out.println(" ");
        System.out.println(" \"SDN\" - Software-defined networking ");
    }
}
