package com.example;

/**
 * Hello world!
 *
 */
public class T2Q3
{
    public static void main( String[] args )
    {
        System.out.println(" ");
        // Question 3a) System.Println("Java Programming");
        System.out.println( "Java Programming" );
        // Question 3b) System.in.println("Intorduction to Java!")
        System.out.println("Introduction to Java!");
        // Question 3c) System.out.println("\t is the horizontal tab character");
        System.out.println("\\t is the horizontal tab character");
        // Question 3d) system.out.println("Java is case sensitive!");
        System.out.println("Java is case sensitive");
    }
}
