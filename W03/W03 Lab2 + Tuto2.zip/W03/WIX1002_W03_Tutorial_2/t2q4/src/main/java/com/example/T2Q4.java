package com.example;

/**
 * Hello world!
 *
 */
public class T2Q4
{
    public static void main( String[] args )
    {
        System.out.println(" ");
        // 4a)
        int matricNum ; 
        // 4b) 
        double pi ; 
        // 4c) 
        boolean M = false;
        // 4d) 
        long P = 8800000000L;
        // 4e) 
        char letter = 'U'; 
        // 4f) 
        final String PRO = "Java";
        
    }
}
